import javax.swing.*;
import java.awt.event.ActionListener;


public class Main {
    public static void main(String[] args) {

        int index = 0;

        NodeService nodeService1_1 = new NodeService();
        NodeAgency nodeAgency1_1 = new NodeAgency();
        NodeRun nodeRun1_1 = new NodeRun();
        NodeCustomers nodeCustomers1_1 = new NodeCustomers();

        new Do(nodeService1_1,nodeAgency1_1,nodeRun1_1,nodeCustomers1_1 , index);
    }

}

